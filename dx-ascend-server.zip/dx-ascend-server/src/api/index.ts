import { Router } from "express";
import healthRouter from "./health.routes";
import modbusRouter from "./modbus.routes";
import screensRouter from "./screens.routes";
import bindingsRouter from "./bindings.routes";

const apiRouter = Router();

apiRouter.use(healthRouter);
apiRouter.use(modbusRouter);
apiRouter.use(screensRouter);
apiRouter.use(bindingsRouter);

export default apiRouter;
