import express from "express";
import cors from "cors";
import apiRouter from "./api";

const app = express();

app.use(cors());
app.use(express.json());

app.use("/api", apiRouter);

app.get("/", (req, res) => {
  res.send("DX-Ascend Server v0.1 – API en /api");
});

export default app;
